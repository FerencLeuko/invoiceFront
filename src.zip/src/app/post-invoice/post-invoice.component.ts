import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { InvoiceService } from '../invoice.service';
import { Invoice } from '../model/invoice';
import { Item } from '../model/item';

@Component({
  selector: 'app-post-invoice',
  templateUrl: './post-invoice.component.html',
  styleUrls: ['./post-invoice.component.css']
})
export class PostInvoiceComponent implements OnInit {

  newInvoice : Invoice = new Invoice();

  newItem : Item;

  items : Item[] = [];

  @ViewChild("form")
  form : NgForm;

  constructor( private invoiceService: InvoiceService) { }

  ngOnInit(): void {
    this.postInvoice();
    this.invoiceService.postInvoice(this.newInvoice).subscribe(response => console.log(response));
  }

  createItem(){
    this.form.form.value["items"]= this.items;
    this.items.push( new Item() );
  }

  createInvoice(){
    this.form.form.value["items"]= this.items;
    console.log( this.form )
    console.log( this.items )
  }

  postInvoice(){
    this.items.push( new Item ("AAA", 2, 20 ));
    this.newInvoice.customerName = "AAAA";
    this.newInvoice.issueDate = new Date ();
    this.newInvoice.dueDate = new Date ();
    this.newInvoice.items = this.items;
  }

}
